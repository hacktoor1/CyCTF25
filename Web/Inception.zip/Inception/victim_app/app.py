from flask import Flask, request, jsonify, redirect, make_response
import requests
import json

app = Flask(__name__)


users = {}
sessions = {}


MAX_REDIRECTS = 10


class TooManyRedirectsError(Exception):
    pass



STYLE = """
<style>
body {
    background-color: #000;
    color: #d4af37;
    font-family: 'Papyrus', 'Times New Roman', serif;
    text-align: center;
    margin: 0;
    padding: 0;
}
h1 {
    color: #ffd700;
    text-shadow: 0 0 10px #d4af37;
    font-size: 2.5em;
    margin-top: 50px;
}
h2 {
    color: #e6c200;
    text-shadow: 0 0 5px #b8860b;
}
form {
    background: rgba(34, 27, 0, 0.85);
    border: 2px solid #d4af37;
    border-radius: 15px;
    display: inline-block;
    padding: 30px 50px;
    margin-top: 40px;
    box-shadow: 0 0 20px #d4af37;
}
input[type=text], input[type=password] {
    background-color: #111;
    color: #d4af37;
    border: 1px solid #d4af37;
    border-radius: 5px;
    padding: 10px;
    margin: 10px;
    width: 250px;
    text-align: center;
}
input[type=submit] {
    background-color: #d4af37;
    color: black;
    border: none;
    border-radius: 5px;
    padding: 10px 25px;
    cursor: pointer;
    font-weight: bold;
}
input[type=submit]:hover {
    background-color: #ffd700;
}
a {
    color: #ffd700;
    text-decoration: none;
    font-weight: bold;
}
a:hover {
    text-decoration: underline;
}
pre {
    color: #ffeb7a;
    text-align: left;
    background: rgba(20, 15, 0, 0.8);
    padding: 20px;
    border: 1px solid #d4af37;
    border-radius: 10px;
    display: inline-block;
}
</style>
"""


@app.route('/internal/flag')
def get_internal_flag():
    if request.remote_addr != '127.0.0.1':
        return "Forbidden", 403
    return "flag{Dummy_flag_dont_submit}", 200


@app.route('/internal/error_service')
def get_internal_error():
    if request.remote_addr != '127.0.0.1':
        return "Forbidden", 403
    return "Internal Server Error in error_service", 500



@app.route('/')
def home():
    return STYLE + """
    <h1>☥ Pharaoh’s Gate ☥</h1>
    <h2>Welcome to the Enterprise Health Checker v2</h2>
    <p><a href='/login'>Login</a> | <a href='/signup'>Sign Up</a></p>
    """


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return STYLE + """
        <h1>Sign Up Here</h1>
        <form method="post">
            <input type="text" name="username" placeholder="username" required><br>
            <input type="password" name="password" placeholder="password" required><br>
            <input type="submit" value="Register">
        </form>
        <p><a href='/login'>Already have an account? Enter the Gate</a></p>
        """
    else:
        username = request.form.get('username')
        password = request.form.get('password')
        if username in users:
            return STYLE + "<h2>This username already exists.</h2><a href='/login'>Try logging in</a>"
        users[username] = password
        return redirect('/login')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return STYLE + """
        <h1>Login Here</h1>
        <form method="post">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="submit" value="Login">
        </form>
        <p><a href='/signup'>Don’t have an account? Sign up</a></p>
        """
    else:
        username = request.form.get('username')
        password = request.form.get('password')
        if username in users and users[username] == password:
            resp = make_response(redirect('/portal'))
            sessions[username] = True
            resp.set_cookie('user', username)
            return resp
        return STYLE + "<h2>Wrong Credentials. The gods deny your entry.</h2><a href='/login'>Try again</a>"


@app.route('/portal')
def portal():
    username = request.cookies.get('user')
    if not username or username not in sessions:
        return redirect('/login')
    return STYLE + f"""
        <h1>Welcome, {username}!</h1>
        <h2>☥ Enterprise Health Checker v2 ☥</h2>
        <p>Submit a JSON file — we shall inspect its divine health.</p>
        <form action="/check" method="post">
            <input type="text" name="url" size="70" placeholder="http://example.com/health.json">
            <input type="submit" value="Check">
        </form>
        <p><a href='/logout'>Logout</a></p>
    """


@app.route('/logout')
def logout():
    username = request.cookies.get('user')
    if username in sessions:
        del sessions[username]
    resp = make_response(redirect('/'))
    resp.delete_cookie('user')
    return resp



@app.route('/check', methods=['POST'])
def check_url():
    url = request.form.get('url')
    try:
        final_response = custom_fetch(url)
        parsed_json = json.loads(final_response.text)
        return jsonify({"status": "ok", "data": parsed_json})

    except Exception as e:
        error_message = f"FATAL_ERROR: An unhandled exception occurred: {str(e)}\n\n"
        try:
            last_url = str(e).split("Last URL was: ")[1]
            final_attempt = requests.get(last_url, timeout=2)
            error_message += f"--- Final Response Body ---\n{final_attempt.text}"
        except:
            error_message += "Could not retrieve final response body."
        return STYLE + f"<pre>{error_message}</pre>", 500


def custom_fetch(url):
    current_url = url
    for i in range(MAX_REDIRECTS + 1):
        if i == MAX_REDIRECTS:
            raise TooManyRedirectsError(f"Exceeded redirect limit of {MAX_REDIRECTS}. Last URL was: {current_url}")

        response = requests.get(current_url, allow_redirects=False, timeout=3)

        if 300 <= response.status_code < 400:
            current_url = response.headers['Location']
            if current_url.startswith('/'):
                current_url = requests.compat.urljoin(response.url, current_url)
            continue
        else:
            return response
    return None


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
